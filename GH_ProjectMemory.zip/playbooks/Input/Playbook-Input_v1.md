---
slug: playbook-input
version: 1
tags: [ingest, files]
updated: 2025-08-16
---
# Amaç
Yüklü dosya/ZIP/Web içeriğini envanterleyip kullanılabilir özete dönüştürmek.

## Adımlar
Envanter → Başlık/kavram → Varlık‑ilişki → 10 madde özet → 3 eylem → Etiketle
