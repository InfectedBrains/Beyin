---
slug: playbook-web
version: 1
tags: [web, research]
updated: 2025-08-16
---
# Amaç
Onaylı web adreslerinden 5 bulgu + 3 eylem çıkarımı.

## Adımlar
1) Listeyi doğrula → 2) Onay → 3) Tarama (metin/görsel/ses)  
4) Özet → 5) Etiketle → 6) Çapraz kontrol → 7) Rapor

## Şablon
[Kaynak] – [Tarih]  
**Önemli Bulgular:** 1…5  
**Eylem Önerileri:** 1…3  
Etiketler: [Playbook‑Web], [Konu]
