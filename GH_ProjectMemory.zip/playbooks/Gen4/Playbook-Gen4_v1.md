---
slug: playbook-gen4
version: 1
tags: [runway, gen4, video]
updated: 2025-08-16
---
# Amaç & Kapsam
Runway Gen-4 için tek cümleden başlayıp sinematik kaliteye genişleyen video prompt üretimi.

## Girdiler
- Özne/konu, mekan/zaman, atmosfer/stil kısa notu
- (Varsa) referans görsel/klip
- Üretim öncesi onay

## Çıktılar (DoD)
- 1 temel cümle + 1 tam prompt
- 2 küçük varyasyon
- Sıra korunur: subject→camera→scene→style, negatif ifade yok

## Süreç
1) **Subject motion**: öznenin eylemi.
2) **Camera**: static/handheld/pushes in/tracks...
3) **Scene motion**: toz, yağmur, kalabalık akışı...
4) **Style**: cinematic/live‑action/stylized + ışık/renk.
5) Temizle: kısa, olumlu, net.
6) Varyasyonlar: kamera ya da sahne hareketinde küçük fark.
7) Kontrol & Onay.

## Checklist
- [ ] subject→camera→scene→style
- [ ] Negatif yok
- [ ] Tutarlı hareketler
- [ ] ≥2 varyasyon

## Şablon
**Temel:** `a [subject] [subject motion].`  
**Tam:** `a [subject] [subject motion]. the camera [camera motion]. [scene motion]. [style/lighting].`

## Örnek
`a messenger runs across wet neon streets. the camera handheld tracks at shoulder height. reflections ripple as rain intensifies. cinematic night.`
