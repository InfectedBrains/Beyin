---
slug: playbook-bellek
version: 1
tags: [memory, policy]
updated: 2025-08-16
---
# Amaç
Hibrit hafıza: çekirdek kısa ve kalıcı; ayrıntılar dosyalarda.

## Politika
- Çekirdek: ≤15 madde, kısa kural cümleleri.
- Ayrıntılar: playbook/icerik dosyaları.
- Sabitleme: “Sabitle …” komutuyla yapılır.

## Komutlar
Çağır / Genişlet / Sabitle / Unut / Ara "…"
