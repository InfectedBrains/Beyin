---
slug: playbook-revizyon
version: 1
tags: [editing, quality]
updated: 2025-08-16
---
# Amaç
Belirtilen kısımları değiştirirken bütünlüğü korumak.

## Süreç
1) Seçim → 2) Etki Analizi → 3) Uyarı+Öneri → 4) Onay → 5) Uygula → 6) Karşılaştırma → 7) QC

## Checklist
- [ ] Sadece belirtilen alan değişti
- [ ] Çakışma analizi yapıldı
- [ ] Onay kaydı var
- [ ] Fark listesi

## Şablonlar
- Değişiklik: “Bölüm X, 2. paragrafı ‘…’ yap.”
- Etki Notu: “Bu, Bölüm Y’de ‘…’ ile çelişebilir.”
- Fark: “- Eski: … / + Yeni: …”
