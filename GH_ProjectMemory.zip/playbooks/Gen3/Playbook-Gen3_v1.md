---
slug: playbook-gen3
version: 1
tags: [runway, gen3, video]
updated: 2025-08-16
---
# Amaç & Kapsam
Runway Gen‑3 için olumlu, net ve hareket odaklı video prompt üretimi.

## Format
`[Camera move]: a [subject] in/at [scene], [brief action]. [lighting/style].`

## İlkeler
- Kamera hareketi **başta**.
- Görüntü+metinse **yalnız hareket** tarif et.
- Negatif dil yok.

## Örnek
`Static shot: a designer at a cluttered desk, sketches calmly. warm indoor light, cinematic.`
